void Quick_Sort(long *Array, int Size);
void Merge_Sort(long *Array, int Size);
